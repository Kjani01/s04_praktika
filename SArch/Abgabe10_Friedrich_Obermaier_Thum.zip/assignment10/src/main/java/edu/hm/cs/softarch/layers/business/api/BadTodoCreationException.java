package edu.hm.cs.softarch.layers.business.api;

/**
 * Exception wird geworfen, wenn ein Todo nicht angelegt werden kann.
 * 
 * @author katz.bastian
 */
public class BadTodoCreationException extends Exception {

	private static final long serialVersionUID = 1L;

	/**
	 * Standard-Konstruktor.
	 * 
	 * @param message
	 *            Fehlermeldung
	 */
	public BadTodoCreationException(String message) {
		super(message);
	}
}
