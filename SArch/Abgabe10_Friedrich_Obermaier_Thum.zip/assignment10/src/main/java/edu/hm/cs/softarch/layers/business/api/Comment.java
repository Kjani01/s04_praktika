package edu.hm.cs.softarch.layers.business.api;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

import edu.hm.cs.softarch.layers.dataaccess.api.Todo;

@Entity
public class Comment {

	String text;
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private Long id;
	
	@ManyToOne
	Todo todo;
	
	
	public void setText(String text) {
		this.text = text;
	}
	
	public String getText() {
		return text;
	}
	
	public void setTodo(Todo todo) {
		this.todo = todo;
	}
	
	public Todo getTodo() {
		return todo;
	}
	

}
