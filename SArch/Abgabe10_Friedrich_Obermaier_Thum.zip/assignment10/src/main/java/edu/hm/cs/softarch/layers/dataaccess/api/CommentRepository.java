package edu.hm.cs.softarch.layers.dataaccess.api;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import edu.hm.cs.softarch.layers.business.api.Comment;

@Repository
public interface CommentRepository extends JpaRepository<Comment, Long> {

}
