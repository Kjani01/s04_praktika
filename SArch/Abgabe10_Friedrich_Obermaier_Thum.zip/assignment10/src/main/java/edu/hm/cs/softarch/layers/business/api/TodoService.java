package edu.hm.cs.softarch.layers.business.api;

import java.util.Collection;

import edu.hm.cs.softarch.layers.dataaccess.api.Todo;

/**
 * Fachlogik für eine Verwaltung von {@link Todo}s.
 * 
 * @author katz.bastian
 */
public interface TodoService {

	/**
	 * @return alle wichtigen Todos
	 */
	Collection<TodoDto> findeWichtigeTodos();

	/**
	 * @return alle unwichtigen Todos
	 */
	Collection<TodoDto> findeUnwichtigeTodos();

	/**
	 * @param neu
	 *            erfasst ein neues {@link Todo}
	 * @param login
	 * @throws BadTodoCreationException
	 *             wenn das {@link Todo} nciht validiert werden kann, weil z.B.
	 *             der Text leer ist.
	 */
	void erstelleNeuesTodo(TodoDto neu, String login) throws BadTodoCreationException;

	/**
	 * Schließt ein Todo ab.
	 * 
	 * @param id
	 *            Kennung des Todos
	 */
	void schließeTodoAb(Long id);

	/**
	 * @return Liefert die drei zuletzt geschlossenen Todos
	 */
	Collection<TodoDto> findeLatestClosed();

	/**
	 * Löscht ein Todo endgültig.
	 * 
	 * @param id
	 *            ID des zu löschenden Todos
	 */
	void entferneTodo(Long id);

	/**
	 * Erstellt einen neuen Kommentar
	 * 
	 * @param todoId
	 *            ID des kommentierten Todos
	 * @param text
	 *            Kommentar
	 * @param login
	 *            Login des Kommentators
	 */
	void legeKommentarAb(Long todoId, String text, String login);
}
