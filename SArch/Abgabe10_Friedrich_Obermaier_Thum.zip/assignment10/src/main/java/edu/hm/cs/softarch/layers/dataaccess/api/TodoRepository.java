package edu.hm.cs.softarch.layers.dataaccess.api;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface TodoRepository extends JpaRepository<Todo, Long>{

	List<Todo> findByImportantAndAbgeschlossenAmIsNullOrderByTextAsc(boolean b);

	List<Todo> findTop3ByAbgeschlossenAmIsNotNullOrderByAbgeschlossenAmDesc();

}
