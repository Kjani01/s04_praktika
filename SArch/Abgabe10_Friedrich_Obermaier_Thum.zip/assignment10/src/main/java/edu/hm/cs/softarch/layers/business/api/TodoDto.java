package edu.hm.cs.softarch.layers.business.api;

import java.util.ArrayList;
import java.util.List;

/**
 * Repräsentation eines Vorhabens.
 * 
 * @author katz.bastian
 */
public class TodoDto {
	private Long id;

	private String text;
	
	private boolean important = false;

	private List<CommentDto> comments = new ArrayList<>();
	
	private String creator;
	
	public String getCreator() {
		return creator;
	}

	public void setCreator(String creator) {
		this.creator = creator;
	}

	public TodoDto() {
		//
	}
	
	public TodoDto(Long id, String text, boolean important, String creatorName, List<CommentDto> comments) {
		super();
		this.id = id;
		this.text = text;
		this.important = important;
		this.creator = creatorName;
		this.comments = comments;
	}
	
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}
	
	public boolean isImportant() {
		return important;
	}

	public void setImportant(boolean important) {
		this.important = important;
	}

	public List<CommentDto> getComments() {
		return comments;
	}
}
