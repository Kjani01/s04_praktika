package edu.hm.cs.softarch.layers.dataaccess.api;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import edu.hm.cs.softarch.layers.business.api.Comment;

/**
 * Repräsentation eines Vorhabens.
 * 
 * @author katz.bastian
 */
@Entity
public class Todo {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private Long id;
	
	@Column(length=1000)
	private String text;
	private boolean important;
	
	@Temporal(TemporalType.TIMESTAMP)
	private Date abgeschlossenAm;
	
	@ManyToOne
	private User user;
	
	@OneToMany(mappedBy="todo")
	List<Comment> comments = new ArrayList<Comment>();

	public Date getAbgeschlossenAm() {
		return abgeschlossenAm;
	}

	public void setAbgeschlossenAm(Date abgeschlossenAm) {
		this.abgeschlossenAm = abgeschlossenAm;
	}

	public boolean isImportant() {
		return important;
	}

	public void setImportant(boolean important) {
		this.important = important;
	}

	public Todo() {
		// Default-Konstruktor für JPA
	}
	
	public Todo(Long id, String text, boolean important, User user, List<Comment> comments) {
		super();
		this.important = important;
		this.id = id;
		this.text = text;
		this.user = user;
		this.comments = comments;
	}
	
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}
	
	public void setUser(User user) {
		this.user = user;
	}
	
	public User getUser() {
		return user;
	}
	
	public void setComments(List<Comment> comments) {
		this.comments = comments;
	}
	
	public List<Comment> getComments() {
		return comments;
	}
}
