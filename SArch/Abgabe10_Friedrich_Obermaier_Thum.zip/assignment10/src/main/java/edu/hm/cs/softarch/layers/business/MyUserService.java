package edu.hm.cs.softarch.layers.business;

import java.util.Collections;
import java.util.Optional;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import edu.hm.cs.softarch.layers.dataaccess.api.User;
import edu.hm.cs.softarch.layers.dataaccess.api.UserRepository;

/**
 * Dieser UserService dient vor allem Spring Security zur Authentifizierung. Es
 * werden ddrei Dummy-Accounts erstellt.
 * 
 * @author katz.bastian
 */
@Service
@Transactional
public class MyUserService implements UserDetailsService {

	private UserRepository userRepository;

	@Autowired
	public void setUserRepository(UserRepository userRepository) {
		this.userRepository = userRepository;
	}

	@PostConstruct
	public void init() {
		userRepository.save(new User("justus", "Justus Jonas", ""));
		userRepository.save(new User("peter", "Peter Shaw", ""));
		userRepository.save(new User("bob", "Robert Andrews", ""));
	}

	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		Optional<User> findeMitspieler = userRepository.findById(username);
		if (findeMitspieler.isPresent()) {
			User user = findeMitspieler.get();
			return new org.springframework.security.core.userdetails.User(user.getLogin(),
					"{noop}" + user.getPassword(), Collections.emptySet());
		} else {
			throw new UsernameNotFoundException("");
		}
	}
}
