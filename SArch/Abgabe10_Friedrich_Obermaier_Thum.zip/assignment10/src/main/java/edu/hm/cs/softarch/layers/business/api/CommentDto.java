package edu.hm.cs.softarch.layers.business.api;

import java.util.Date;

/**
 * Transferobjekt zum Austausch von Kommentaren zwischen Service und
 * Präsentation.
 * 
 * @author katz.bastian
 */
public class CommentDto {

	String text;
	String creator;
	Date date;

	public CommentDto() {
		// Default constructor needed!
	}

	public CommentDto(String text, String creator, Date date) {
		this.text = text;
		this.creator = creator;
		this.date = date;
	}

	public String getCreator() {
		return creator;
	}

	public void setCreator(String creator) {
		this.creator = creator;
	}

	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

}
