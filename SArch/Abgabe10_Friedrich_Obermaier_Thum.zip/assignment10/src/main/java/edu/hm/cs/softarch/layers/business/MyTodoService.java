package edu.hm.cs.softarch.layers.business;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;

import javax.transaction.Transactional;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import edu.hm.cs.softarch.layers.business.api.BadTodoCreationException;
import edu.hm.cs.softarch.layers.business.api.Comment;
import edu.hm.cs.softarch.layers.business.api.CommentDto;
import edu.hm.cs.softarch.layers.business.api.TodoDto;
import edu.hm.cs.softarch.layers.business.api.TodoService;
import edu.hm.cs.softarch.layers.dataaccess.api.CommentRepository;
import edu.hm.cs.softarch.layers.dataaccess.api.Todo;
import edu.hm.cs.softarch.layers.dataaccess.api.TodoRepository;
import edu.hm.cs.softarch.layers.dataaccess.api.User;
import edu.hm.cs.softarch.layers.dataaccess.api.UserRepository;

/**
 * Einfache Implementierung einer Fachlogik.
 * 
 * @author katz.bastian
 */
@Service
@Transactional(rollbackOn = Exception.class)
public class MyTodoService implements TodoService {

	private static final Logger LOG = LoggerFactory.getLogger(MyTodoService.class);

	private TodoRepository todoRepo;
	private UserRepository userRepo;
	private CommentRepository commentRepo;
	
	private User user;
	
	@Autowired
	public void setUserRepo(UserRepository userRepo) {
		this.userRepo = userRepo;
	}
	
	@Autowired
	public void setTodoRepo(TodoRepository repo) {
		todoRepo = repo;
	}
	
	@Autowired
	public void setCommentRepo(CommentRepository commentRepo) {
		this.commentRepo = commentRepo;
	}

	@Override
	public void erstelleNeuesTodo(TodoDto neu, String login) throws BadTodoCreationException {

		if (StringUtils.isBlank(neu.getText())) {
			throw new BadTodoCreationException("Todo darf nicht leer sein.");
		}
		// TODO: Hier fehlt die Verknüpfung des Todos mit einem User!
		user = userRepo.findById(login).get();
		//user = userRepo.getOne(login);
//		System.err.println("User: " + user.getName());

		Todo todo = new Todo(neu.getId(), neu.getText(), neu.isImportant(), user, new ArrayList<Comment>());
		todoRepo.save(todo);
	}

	@Override
	public void schließeTodoAb(Long id) {
		todoRepo.findById(id).get().setAbgeschlossenAm(new Date());
	}

	@Override
	public void entferneTodo(Long id) {
		todoRepo.deleteById(id);
	}

	@Override
	public List<TodoDto> findeWichtigeTodos() {
		return mapToDtoList(todoRepo.findByImportantAndAbgeschlossenAmIsNullOrderByTextAsc(true));
	}

	@Override
	public List<TodoDto> findeUnwichtigeTodos() {
		return mapToDtoList(todoRepo.findByImportantAndAbgeschlossenAmIsNullOrderByTextAsc(false));
	}

	@Override
	public Collection<TodoDto> findeLatestClosed() {
		return mapToDtoList(todoRepo.findTop3ByAbgeschlossenAmIsNotNullOrderByAbgeschlossenAmDesc());
	}

	private List<TodoDto> mapToDtoList(List<Todo> todos) {
		List<TodoDto> result = new LinkedList<TodoDto>();
		for (Todo todo : todos) {
			TodoDto todoDto = new TodoDto(todo.getId(), todo.getText(), todo.isImportant(), todo.getUser().getName(), new ArrayList<CommentDto>());

//			System.err.println("CommentRepo: " + commentRepo);
			// TODO: Hier müssen die Kommentare aus den Todos ausgelesen werden!
			for (Comment c : todo.getComments()) {
				todoDto.getComments().add(new CommentDto(c.getText(), "anonymous", new Date()));
			}
			
			/*todoDto.getComments()
					.add(new CommentDto("Das hier ist ein Dummy-Kommentar", "<Kommentar-Ersteller>", new Date()));
			todoDto.getComments().add(new CommentDto("Das hier ist ein längerer Dummy-Kommentar dideldum dideldum",
					"<Kommentar-Ersteller>", new Date()));*/

			result.add(todoDto);
		}
		return result;
	}

	@Override
	public void legeKommentarAb(Long todoId, String text, String login) {
		LOG.info("{} hat Todo #{} kommentiert: {}", login, todoId, text);
		Todo todo = todoRepo.getOne(todoId);
		Comment newComment = new Comment();
		newComment.setText(text);
		newComment.setTodo(todo);
//		System.err.println("Vor: " + todo.getComments());
		todo.getComments().add(newComment);
		commentRepo.save(newComment);
		//todoRepo.save(todo);
//		System.err.println("Nach: " + todo.getComments());
		// TODO: Hier müssen Kommentare erstellt werden und mit dem Todo und dem
		// User in Beziehung gesetzt werdne.
	}

}
