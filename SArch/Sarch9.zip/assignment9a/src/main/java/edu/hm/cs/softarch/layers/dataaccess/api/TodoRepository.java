package edu.hm.cs.softarch.layers.dataaccess.api;

import java.util.Collection;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface TodoRepository extends JpaRepository<Todo, Long>{
		
	List<Todo> findByImportantTrue();
	
	List<Todo> findByImportantFalse();
	
	//List<Todo> findOptionalTop3ByabgeschlossenAm();
	
}
