package edu.hm.cs.softarch.layers.business.api;

/**
 * Repräsentation eines Vorhabens.
 * 
 * @author katz.bastian
 */
public class TodoDto {
	private Long id;

	private String text;
	
	private boolean important = false;

	public TodoDto() {
		//
	}
	
	public TodoDto(Long id, String text, boolean important) {
		super();
		this.id = id;
		this.text = text;
		this.important = important;
	}
	
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}
	
	public boolean isImportant() {
		return important;
	}

	public void setImportant(boolean important) {
		this.important = important;
	}
}
