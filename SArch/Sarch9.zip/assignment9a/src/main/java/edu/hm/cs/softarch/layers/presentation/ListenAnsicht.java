package edu.hm.cs.softarch.layers.presentation;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import edu.hm.cs.softarch.layers.business.api.BadTodoCreationException;
import edu.hm.cs.softarch.layers.business.api.TodoDto;
import edu.hm.cs.softarch.layers.business.api.TodoService;

/**
 * Controller für die Steuerung der Anzeige der Listenansicht.
 * 
 * @author katz.bastian
 */
@Controller
public class ListenAnsicht {

	private TodoService todoService;

	/**
	 * Konstruktor.
	 * 
	 * @param todoService
	 *            Todo-Service
	 */
	@Autowired
	public ListenAnsicht(TodoService todoService) {
		this.todoService = todoService;
	}

	/**
	 * Erzeugt die Listenansicht.
	 * 
	 * @param model
	 *            Spring-MVC-Model
	 * @return Listenansicht (Template).
	 */
	@GetMapping
	public String showTodoList(Model model) {
		model.addAttribute("wichtigeTodos", todoService.findeWichtigeTodos());
		model.addAttribute("unwichtigeTodos", todoService.findeUnwichtigeTodos());
//		model.addAttribute("Letzte 3", todoService.findeLetzteTodos()); 
		model.addAttribute("newTodo", new TodoDto());
		return "todoliste";
	}

	/**
	 * Erstellt ein neues Todo.
	 * 
	 * @param model
	 *            Spring-MVC-Model
	 * @param neu
	 *            zu erzeugendes Element. Text darf nicht leer sein.
	 * @return Listenansicht
	 */
	@PostMapping("/add")
	public String addTodo(Model model, @ModelAttribute("newTodo") TodoDto neu) {
		try {
			todoService.erstelleNeuesTodo(neu);
			model.addAttribute("success", "Todo erfolgreich erstellt.");
		} catch (BadTodoCreationException e) {
			model.addAttribute("error", e.getMessage());
		}
		return showTodoList(model);
	}

	/**
	 * @param model
	 *            Spring-MVC-Model
	 * @param id
	 *            ID des zu löschenden Elements
	 * @return Aktualisierte Listenansicht.
	 */
	@PostMapping("/{id}/delete")
	public String delete(Model model, @PathVariable("id") Long id) {
		todoService.schließeTodoAb(id);
		model.addAttribute("success", "Erfolgreich gelöscht");
		return showTodoList(model);
	}

}
