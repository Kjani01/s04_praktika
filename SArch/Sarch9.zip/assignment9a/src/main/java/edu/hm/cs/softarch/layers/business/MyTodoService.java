package edu.hm.cs.softarch.layers.business;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import edu.hm.cs.softarch.layers.business.api.BadTodoCreationException;
import edu.hm.cs.softarch.layers.business.api.TodoDto;
import edu.hm.cs.softarch.layers.business.api.TodoService;
import edu.hm.cs.softarch.layers.dataaccess.api.Todo;
import edu.hm.cs.softarch.layers.dataaccess.api.TodoRepository;

/**
 * Einfache Implementierung einer Fachlogik.
 * 
 * @author katz.bastian
 */
@Service
public class MyTodoService implements TodoService {

	@Autowired
	TodoRepository repo;
	
	/**
	 * Konstruktor.
	 * 
	 * @param todoSpeicher
	 *            Persistenz
	 */
	public MyTodoService() {
	}

	@Override
	public Collection<TodoDto> findeAlleTodos() {
		return repo.findAll().stream().map(e -> new TodoDto(e.getId(), e.getText(), e.isImportant()))
				.collect(Collectors.toList());
	}

	@Override
	public void erstelleNeuesTodo(TodoDto neu) throws BadTodoCreationException {
		if (StringUtils.isBlank(neu.getText())) {
			throw new BadTodoCreationException("Todo darf nicht leer sein.");
		}
		repo.save(new Todo(neu.getId(), neu.getText(), neu.isImportant()));
	}

	@Override
	public void schließeTodoAb(Long id) {
//		repo.delete(id);
		repo.findById(id).get().setAbgeschlossenAm(new Date());
	}

	@Override
	public Collection<TodoDto> findeWichtigeTodos() {
		//return findeAlleTodos().stream().filter(t->t.isImportant()).collect(Collectors.toList());
	
		List<Todo> l =  repo.findByImportantTrue();
		List<TodoDto> d = new ArrayList<>();
		
		for (Todo i : l) {
			d.add(new TodoDto(i.getId(), i.getText(), i.isImportant()));
		}
		
		return d;
	}

	@Override
	public Collection<TodoDto> findeUnwichtigeTodos() {
		//return findeAlleTodos().stream().filter(t->!t.isImportant()).collect(Collectors.toList());
	
		List<Todo> l =  repo.findByImportantFalse();
		List<TodoDto> d = new ArrayList<>();
		
		for (Todo i : l) {
			d.add(new TodoDto(i.getId(), i.getText(), i.isImportant()));
		}
		
		return d;
	}
	
//	@Override
//	public Collection<TodoDto> findeLetzteTodos() {
//		//return findeAlleTodos().stream().filter(t->!t.isImportant()).collect(Collectors.toList());
//	
//		List<Todo> l =  repo.findOptionalTop3ByabgeschlossenAm();
//		List<TodoDto> d = new ArrayList<>();
//		
//		for (Todo i : l) {
//			d.add(new TodoDto(i.getId(), i.getText(), i.isImportant()));
//		}
//		
//		return d;
//	}

}
