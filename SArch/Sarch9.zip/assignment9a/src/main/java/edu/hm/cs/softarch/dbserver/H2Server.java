package edu.hm.cs.softarch.dbserver;

import java.sql.SQLException;

import org.h2.tools.Server;

/**
 * Diese Klasse dient nur dem einfachen Starten eines Datenbankservers.
 * 
 * @author katz.bastian
 */
public class H2Server {
	
	public static void main(String[] args) throws SQLException {
		Server.main();
	}
}
