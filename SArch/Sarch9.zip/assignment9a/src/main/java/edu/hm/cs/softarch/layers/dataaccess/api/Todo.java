package edu.hm.cs.softarch.layers.dataaccess.api;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * Repräsentation eines Vorhabens.
 * 
 * @author katz.bastian
 */
@Entity
public class Todo {
	@Id
	//@GeneratedValue(strategy=AUTO)
	private Long id;
	@Column(length=1000)
	private String text;
	private boolean important;
	@Temporal(TemporalType.DATE)
	Date abgeschlossenAm;

	public boolean isImportant() {
		return important;
	}

	public void setImportant(boolean important) {
		this.important = important;
	}
	
	public Todo() {
		
	}

	public Todo(Long id, String text, boolean important) {
		super();
		this.important = important;
		this.id = id;
		this.text = text;
		this.abgeschlossenAm = null;
	}
	
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}
	
	public void setAbgeschlossenAm(Date date) {
		this.abgeschlossenAm = date;
	}
	
	public Date getAbgeschlossenAm() {
		return abgeschlossenAm;
	}
}
