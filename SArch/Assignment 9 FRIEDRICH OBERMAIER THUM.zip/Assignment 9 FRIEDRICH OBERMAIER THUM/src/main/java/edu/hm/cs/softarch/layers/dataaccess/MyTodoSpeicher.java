package edu.hm.cs.softarch.layers.dataaccess;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Repository;

import edu.hm.cs.softarch.layers.dataaccess.api.Todo;
import edu.hm.cs.softarch.layers.dataaccess.api.TodoSpeicher;

/**
 * Einfache Implementierung einer Ablage für {@link Todo}s.
 * @author katz.bastian
 *
 */
@Repository
public class MyTodoSpeicher implements TodoSpeicher {

	private Map<Long, Todo> todos = new HashMap<>();
	private Long nextId = 1L;

	@Override
	public Collection<Todo> findAll() {
		return todos.values();
	}

	@Override
	public void save(Todo neu) {
		if (neu.getId() == null) {
			neu.setId(nextId++);
		}
		todos.put(neu.getId(), neu);
	}

	@Override
	public void remove(Long id) {
		todos.remove(id);
	}

}
