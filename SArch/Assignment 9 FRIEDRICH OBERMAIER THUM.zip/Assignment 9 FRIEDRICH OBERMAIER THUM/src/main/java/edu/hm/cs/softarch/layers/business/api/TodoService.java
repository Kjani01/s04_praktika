package edu.hm.cs.softarch.layers.business.api;

import java.util.Collection;

import edu.hm.cs.softarch.layers.dataaccess.api.Todo;

/**
 * Fachlogik für eine Verwaltung von {@link Todo}s.
 * 
 * @author katz.bastian
 */

public interface TodoService {
	/**
	 * @return alle abgelegten Todos
	 */
	Collection<TodoDto> findeAlleTodos();

	/**
	 * @return alle wichtigen Todos
	 */
	Collection<TodoDto> findeWichtigeTodos();
	
	/**
	 * @return alle unwichtigen Todos
	 */
	Collection<TodoDto> findeUnwichtigeTodos();

	Collection<TodoDto> findeAbgeschlosseneTodos();
	
	/**
	 * @param neu
	 *            erfasst ein neues {@link Todo}
	 * @throws BadTodoCreationException
	 *             wenn das {@link Todo} nciht validiert werden kann, weil z.B.
	 *             der Text leer ist.
	 */
	void erstelleNeuesTodo(TodoDto neu) throws BadTodoCreationException;

	/**
	 * Schließt ein Todo ab.
	 * 
	 * @param id Kennung des Todos
	 */
	void schließeTodoAb(Long id);


}
