package edu.hm.cs.softarch.layers.dataaccess.api;

import java.util.Collection;

public interface TodoSpeicher {

	Collection<Todo> findAll();

	void save(Todo neu);

	void remove(Long id);
}
