package edu.hm.cs.softarch.layers.business;

import java.util.Collection;
import java.util.Date;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import edu.hm.cs.softarch.layers.business.api.BadTodoCreationException;
import edu.hm.cs.softarch.layers.business.api.TodoDto;
import edu.hm.cs.softarch.layers.business.api.TodoService;
import edu.hm.cs.softarch.layers.dataaccess.api.Todo;
import edu.hm.cs.softarch.layers.dataaccess.api.TodoRepository;

/**
 * Einfache Implementierung einer Fachlogik.
 * 
 * @author katz.bastian
 */
@Service
public class MyTodoService implements TodoService {

	@Autowired
	TodoRepository repo;
	
	/**
	 * Konstruktor.
	 */
	public MyTodoService() {};

	@Override
	public Collection<TodoDto> findeAlleTodos() {
		return repo.findAll().stream().map(e -> new TodoDto(e.getId(), e.getText(), e.isImportant())).collect(Collectors.toList());
	}

	@Override
	public void erstelleNeuesTodo(TodoDto neu) throws BadTodoCreationException {
		if (StringUtils.isBlank(neu.getText())) {
			throw new BadTodoCreationException("Todo darf nicht leer sein.");
		}
		repo.save(new Todo(neu.getId(), neu.getText(), neu.isImportant()));
	}

	@Override
	public void schließeTodoAb(Long id) {
		//repo.deleteById(id);
		Todo t = repo.findById(id).get();
		t.setAbgeschlossenAm(new Date()); //def const for Date is set to "now"
		repo.save(t);
	}

	@Override
	public Collection<TodoDto> findeWichtigeTodos() {
		//return findeAlleTodos().stream().filter(t->t.isImportant()).collect(Collectors.toList());
		return repo.findByAbgeschlossenAmIsNullAndImportantOrderByTextAsc(true).stream().map(e -> new TodoDto(e.getId(), e.getText(), e.isImportant())).collect(Collectors.toList());
	}

	@Override
	public Collection<TodoDto> findeUnwichtigeTodos() {
		//return findeAlleTodos().stream().filter(t->!t.isImportant()).collect(Collectors.toList());
		return repo.findByAbgeschlossenAmIsNullAndImportantOrderByTextAsc(false).stream().map(e -> new TodoDto(e.getId(), e.getText(), e.isImportant())).collect(Collectors.toList());
	}

	@Override
	public Collection<TodoDto> findeAbgeschlosseneTodos() {
		return repo.findTop3ByAbgeschlossenAmNotNullOrderByAbgeschlossenAmDesc().stream().map(e -> new TodoDto(e.getId(), e.getText(), e.isImportant())).collect(Collectors.toList());
	}

}
