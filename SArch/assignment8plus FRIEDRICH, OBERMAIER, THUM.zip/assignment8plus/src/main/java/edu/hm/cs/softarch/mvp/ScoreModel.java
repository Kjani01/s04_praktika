package edu.hm.cs.softarch.mvp;

import java.util.ArrayDeque;
import java.util.Deque;
import java.util.HashSet;
import java.util.Set;

import org.apache.commons.lang3.tuple.ImmutablePair;
import org.apache.commons.lang3.tuple.Pair;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Klasse zum Zählen eines Ergebnisses im Hand- oder Fußball.
 * 
 * @author katz.bastian
 */
public class ScoreModel {

	private static final Logger LOG = LoggerFactory.getLogger(ScoreModel.class);

	// Torzähler der Heimmannschaft
	private int homeScore = 0;

	// Torzähler der Gastmannschaft
	private int guestScore = 0;

	// Speicher der vergangenen Spielstände für Undo-Funktion
	private Deque<Pair<Integer, Integer>> history = new ArrayDeque<>();

	// Liste der registrierten Beobachter
	private Set<Observer> observers = new HashSet<>();

	/**
	 * Observable-Methode zum Hinzufügen eines Observers.
	 * 
	 * @param observer
	 */
	public void addObserver(Observer observer) {
		observers.add(observer);
	}

	/**
	 * Benachrichtigung aller Observer.
	 */
	private void notifyObservers() {
		for (Observer o : observers) {
			o.update();
		}
	}

	/**
	 * Entfernt einen gegebenen Observer.
	 * 
	 * @param observer
	 */
	public void removeObserver(Observer observer) {
		observers.remove(observer);
	}

	/** Erhöht den Torzähler der Heimmannschaft */
	public void incrementHomeScore() {
		saveState();
		homeScore++;
		LOG.debug("Home score set to {}, now at {}:{}.", homeScore, homeScore, guestScore);
		notifyObservers();
	}

	/** Erhöht den Torzähler der Gastmannschaft */
	public void incrementGuestScore() {
		saveState();
		guestScore++;
		LOG.debug("Guest score set to {}, now at {}:{}.", guestScore, homeScore, guestScore);
		notifyObservers();
	}

	/** Hilfsmethode zur Speicherung eines Spielstandes (Undo-Funktion) */
	private void saveState() {
		history.push(new ImmutablePair<Integer, Integer>(homeScore, guestScore));
	}

	/**
	 * @return ob eine Undo-Funktion zur Verfügung steht
	 */
	public boolean canUndo() {
		return !history.isEmpty();
	}

	/** Setzt den Spielstand auf den vorherigen Wert zurück. */
	public void undo() {
		if (canUndo()) {
			Pair<Integer, Integer> previousState = history.pop();
			homeScore = previousState.getLeft();
			guestScore = previousState.getRight();
		}
		LOG.debug("Score reset to {}:{}.", homeScore, guestScore);
		notifyObservers();
	}

	/** @return Torzähler der Heimmannschaft */
	public int getHomeScore() {
		return homeScore;
	}

	/** @return Torzähler der Gastmannschaft */
	public int getGuestScore() {
		return guestScore;
	}

}
