package edu.hm.cs.softarch.mvp;

/**
 * Anwendungsklasse, erstellt zwei Presenter mit zwei identischen Views, um die
 * Kommunikation über das Modell zu demonstrieren.
 * 
 * @author katz.bastian
 */
public class Main {

	/**
	 * Main-Methode.
	 * 
	 * @param args
	 *            Parameter. Werden ignoriert.
	 */
	public static void main(String[] args) {
		ScoreModel score = new ScoreModel();

		// Erzeuge zwei Ansichten zu Demonstrationszwecken
		for (int i = 0; i<2; i++) {
			View view = new SwingView();
			view.setPresenter(new Presenter(score, view));
		}
	}
}
