package edu.hm.cs.softarch.mvp;

/**
 * Interface für eine Anzeigemaske. Enthält
 * <ul>
 * <li>Setter für den Presenter (wegen der wechselseitigen Abhängigkeit)</li>
 * <li>Setter für alle Werte in Widgets, die in der Anzeige auftauchen.</li>
 * <li>Getter für alle änderbaren Werte in Widgets (hier: keine)</li>
 * </ul>
 * 
 * @author katz.bastian
 */
public interface View {

	void setPresenter(Presenter presenter);
	
	void setHomeScore(int score);
	
	void setGuestScore(int score);

}
