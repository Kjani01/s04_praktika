package edu.hm.cs.softarch.mvp;

/**
 * Einfaches Observer-Interface für die Registrierung am Modell.
 * 
 * @author katz.bastian
 */
public interface Observer {

	/** Fordert zur Aktualisierung des Beobachters auf. */
	void update();
}
