package edu.hm.cs.softarch.mvp;

import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.GroupLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;

/**
 * Anzeige für ein Spielstand ({@link Score}).
 * 
 * @author katz.bastian
 */
public class SwingView extends JFrame implements View {

	private static final long serialVersionUID = 1L;
	private static final Font SCORE_FONT = new Font("Sans", Font.BOLD, 100);
	private static final Font SMALL_FONT = new Font("Sans", Font.BOLD, 15);

	private Presenter presenter;

	private JLabel homeScore;
	private JLabel guestScore;
	private JButton homeScoreButton;
	private JButton guestScoreButton;
	private JButton undoButton;

	public SwingView() {
		this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

		// Einhängen in das Schließen des Fensters
		addWindowListener(new WindowAdapter() {

			@Override
			public void windowClosing(WindowEvent e) {
				// Code hier wird beim Schließen des Fensters ausgeführt
				presenter.removeFromObserver();
				super.windowClosing(e);
			}
		});

		// Erzeugung des Panels ist ausgelagert
		createPanel();

		this.pack();
		this.setVisible(true);
	}

	@Override
	public void setPresenter(Presenter presenter) {
		this.presenter = presenter;
	}

	/*
	 * Hilfmethoden zur Erzeugung von Elementen und Layout, muss nicht verändert
	 * werden.
	 */

	private JPanel createPanel() {
		// Erzeugung des Panels
		JPanel panel = new JPanel();
		this.add(panel);

		// Überschriften
		JLabel homeCaption = createCaption("Tore Heim");
		panel.add(homeCaption);
		JLabel guestCaption = createCaption("Tore Gast");
		panel.add(guestCaption);

		// Ergebnisziffern
		homeScore = createScoreElement(180, "0");
		panel.add(homeScore);
		JLabel separator = createScoreElement(30, ":");
		panel.add(separator);
		guestScore = createScoreElement(180, "0");
		panel.add(guestScore);

		homeScoreButton = createButton("Tor für Heim!");
		panel.add(homeScoreButton);
		homeScoreButton.addActionListener(new ActionListener() {

		    @Override
		    public void actionPerformed(ActionEvent e) {
		        presenter.incrementHomeScore();
		    }
		});

		guestScoreButton = createButton("Tor für Gast!");
		panel.add(guestScoreButton);
		guestScoreButton.addActionListener(new ActionListener() {

		    @Override
		    public void actionPerformed(ActionEvent e) {
		        presenter.incrementGuestScore();
		    }
		});

		undoButton = createButton("Undo");
		panel.add(undoButton);
		undoButton.addActionListener(new ActionListener() {

		    @Override
		    public void actionPerformed(ActionEvent e) {
		        presenter.undo();
		    }
		});


		// Erstellen des Layouts
		GroupLayout layout = new GroupLayout(panel);
		panel.setLayout(layout);
		layout.setVerticalGroup(layout.createSequentialGroup()
				.addGroup(layout.createParallelGroup().addComponent(homeCaption).addComponent(guestCaption))
				.addGroup(layout.createParallelGroup().addComponent(homeScore).addComponent(separator)
						.addComponent(guestScore).addGroup(layout.createSequentialGroup().addComponent(homeScoreButton)
								.addComponent(guestScoreButton).addComponent(undoButton))));
		layout.setHorizontalGroup(layout.createSequentialGroup()
				.addGroup(layout.createParallelGroup(GroupLayout.Alignment.CENTER).addComponent(homeCaption)
						.addComponent(homeScore, GroupLayout.PREFERRED_SIZE, GroupLayout.PREFERRED_SIZE,
								GroupLayout.PREFERRED_SIZE))
				.addComponent(separator)
				.addGroup(layout.createParallelGroup(GroupLayout.Alignment.CENTER).addComponent(guestCaption)
						.addComponent(guestScore, GroupLayout.PREFERRED_SIZE, GroupLayout.PREFERRED_SIZE,
								GroupLayout.PREFERRED_SIZE))
				.addGap(40).addGroup(layout.createParallelGroup().addComponent(homeScoreButton)
						.addComponent(guestScoreButton).addComponent(undoButton)));

		return panel;
	}

	private JButton createButton(String label) {
		JButton button = new JButton(label);
		button.setFont(SMALL_FONT);
		return button;
	}

	private JLabel createScoreElement(int width, String text) {
		JLabel scoreElement = new JLabel(text);
		scoreElement.setFont(SCORE_FONT);
		scoreElement.setHorizontalAlignment(SwingConstants.CENTER);
		scoreElement.setPreferredSize(new Dimension(width, 80));
		return scoreElement;
	}

	private JLabel createCaption(String text) {
		JLabel caption = new JLabel(text);
		caption.setFont(SMALL_FONT);
		return caption;
	}

	@Override
	public void setHomeScore(int score) {
		homeScore.setText("" + score);
	}

	@Override
	public void setGuestScore(int score) {
		guestScore.setText("" + score);
	}
}
