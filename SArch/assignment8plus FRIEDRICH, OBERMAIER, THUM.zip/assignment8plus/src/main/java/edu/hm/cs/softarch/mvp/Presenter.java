package edu.hm.cs.softarch.mvp;

/**
 * Presenter für die Spielstands-Dialoge. Presenter kennen das Modell und ein
 * View-Interface. Damit sind sie unabhängig von einer konkreten UI-Technologie.
 * Der Presenter ist als Observer am Modell registriert sein, solange die
 * Abzeige aktiv ist.
 * 
 * @author katz.bastian
 */
public class Presenter implements Observer {

	private ScoreModel score;
	private View view;

	public Presenter(ScoreModel score, View view) {
		this.score = score;
		this.view = view;
		score.addObserver(this);
	}
	
	public void incrementHomeScore() {
		score.incrementHomeScore();
		//update();
	}
	
	public void incrementGuestScore() {
		score.incrementGuestScore();
		//update();
	}
	
	public void undo() {
		score.undo();
		//update();
	}
	
	
	public void removeFromObserver() {
		score.removeObserver(this);
	}

	@Override
	public void update() {
		view.setHomeScore(score.getHomeScore());
		view.setGuestScore(score.getGuestScore());
	}

}
