package edu.hm.cs.softarch.mvp;

import static org.mockito.Mockito.*;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

@RunWith(MockitoJUnitRunner.class)
public class PresenterTest {

	@Mock
	ScoreModel scoreModel;

	@Mock
	View view;

	/**
	 * Testet, dass ein neu erzeugter Presenter in der View die aktuellen Werte
	 * setzt.
	 */
	@Test
	public void testInitialization() {
		when(scoreModel.getGuestScore()).thenReturn(2);
		when(scoreModel.getHomeScore()).thenReturn(7);

		new Presenter(scoreModel, view);

		// Beispiel (funktioniert, sobald View die Methoden implementiert.
//		verify(view, times(1)).setGuestScore(2);
//		verify(view, times(1)).setHomeScore(7);
	}
}
