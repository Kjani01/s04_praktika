package edu.hm.cs.softarch.layers.business;

import java.util.Collection;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import edu.hm.cs.softarch.layers.business.api.TodoService;
import edu.hm.cs.softarch.layers.dataaccess.Todo;
import edu.hm.cs.softarch.layers.dataaccess.api.TodoSpeicher;

@Service
public class MyTodoService implements TodoService {

	private TodoSpeicher todoSpeicher;

	
	public MyTodoService(TodoSpeicher todoSpeicher) {
		this.todoSpeicher = todoSpeicher;
	}
	
	@Override
	public Collection<Todo> findeAlleTodos() {
		return todoSpeicher.findAll();
	}

	@Override
	public void erstelleNeuesTodo(TodoDto neu) throws BadTodoCreationException {
		if (StringUtils.isBlank(neu.getText())) {
			throw new BadTodoCreationException("Todo darf nicht leer sein.");
		}
		todoSpeicher.save(neu.getTodotoSave());
	}

	@Override
	public void löscheTodo(Long id) {
		todoSpeicher.remove(id);
		
	}

}
