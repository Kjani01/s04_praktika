package edu.hm.cs.softarch.layers.dataaccess.api;

import java.util.Collection;

import edu.hm.cs.softarch.layers.dataaccess.Todo;

public interface TodoSpeicher {

	Collection<Todo> findAll();

	void save(Todo neu);

	void remove(Long id);

}
