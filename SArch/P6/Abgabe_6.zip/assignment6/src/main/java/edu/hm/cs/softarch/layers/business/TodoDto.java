package edu.hm.cs.softarch.layers.business;

import edu.hm.cs.softarch.layers.dataaccess.Todo;

public class TodoDto {
	Long id;
	String text;
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getText() {
		return text;
	}
	public void setText(String text) {
		this.text = text;
	}
	
	public Todo getTodotoSave() {
		Todo t =  new Todo();
		t.setId(id);
		t.setText(text);
		return t;
	}

}
