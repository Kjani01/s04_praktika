package edu.hm.cs.softarch.layers.business;

import java.util.Collection;

import edu.hm.cs.softarch.layers.dataaccess.Todo;

public interface TodoService {

	Collection<Todo> findeAlleTodos();

	void erstelleNeuesTodo(TodoDto neu) throws BadTodoCreationException;

	void löscheTodo(Long id);

}
