package edu.hm.cs.softarch.layers.business.api;

import java.util.Collection;

import edu.hm.cs.softarch.layers.business.BadTodoCreationException;
import edu.hm.cs.softarch.layers.business.TodoDto;
import edu.hm.cs.softarch.layers.dataaccess.Todo;

public interface TodoService {

	Collection<Todo> findeAlleTodos();

	void erstelleNeuesTodo(TodoDto neu) throws BadTodoCreationException;

	void löscheTodo(Long id);

}
