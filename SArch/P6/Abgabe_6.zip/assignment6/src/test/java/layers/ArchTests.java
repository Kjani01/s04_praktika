package layers;

import static com.tngtech.archunit.lang.syntax.ArchRuleDefinition.classes;

import org.junit.Before;
import org.junit.Test;
import org.springframework.stereotype.Controller;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

import com.tngtech.archunit.core.domain.JavaClasses;
import com.tngtech.archunit.core.importer.ClassFileImporter;
import com.tngtech.archunit.lang.ArchRule;

public class ArchTests {

	private static final String BASE_PACKAGE = "edu.hm.cs.softarch.layers";
	private static final String BUSINESS_PACKAGE = BASE_PACKAGE + ".business";
	private static final String PRESENTATION_PACKAGE = BASE_PACKAGE + ".presentation";
	private static final String DATA_ACCESS_PACKAGE = BASE_PACKAGE + ".dataaccess";
	private static final String SUBPACKAGES = "..";

	private final ClassFileImporter importer = new ClassFileImporter();
	private JavaClasses classesAnalyzed;

	@Before
	public void importClasses() {
		classesAnalyzed = importer.importPackages(BASE_PACKAGE);
	}

	@Test
	public void onlyAppMayResideOutsideOfLayering() 
			throws Exception {
		ArchRule rule = classes()
				.that().resideOutsideOfPackages(
						BUSINESS_PACKAGE + SUBPACKAGES,
						PRESENTATION_PACKAGE + SUBPACKAGES, 
						DATA_ACCESS_PACKAGE + SUBPACKAGES)
				.should()
				.haveSimpleName("TodoApplication");
		rule.check(classesAnalyzed);
	}

	@Test
	public void businessLayerAccess() throws Exception {
		ArchRule rule = classes()
				.that().resideInAPackage(BUSINESS_PACKAGE + SUBPACKAGES)
				.should().onlyBeAccessed()
				.byClassesThat().resideInAnyPackage(
						BUSINESS_PACKAGE + SUBPACKAGES, 
						PRESENTATION_PACKAGE + SUBPACKAGES);
		rule.check(classesAnalyzed);
	}
	
	@Test
	public void dataaccessLayerAccess() throws Exception {
		ArchRule rule = classes()
				.that().resideInAPackage(DATA_ACCESS_PACKAGE + SUBPACKAGES)
				.should().onlyBeAccessed()
				.byClassesThat().resideInAnyPackage(
						BUSINESS_PACKAGE + SUBPACKAGES, 
						DATA_ACCESS_PACKAGE + SUBPACKAGES);
		rule.check(classesAnalyzed);
	}
	
	@Test
	public void presentationLayerAccess() throws Exception {
		ArchRule rule = classes()
				.that().resideInAPackage(PRESENTATION_PACKAGE + SUBPACKAGES)
				.should().onlyBeAccessed()
				.byClassesThat().resideInAnyPackage(
						PRESENTATION_PACKAGE + SUBPACKAGES);
		rule.check(classesAnalyzed);
	}
	
	@Test
	public void presentationAnnotation() throws Exception {
		ArchRule rule = classes()
				.that().areAnnotatedWith(Controller.class)
				.should().resideInAnyPackage(PRESENTATION_PACKAGE + SUBPACKAGES);
		rule.check(classesAnalyzed);
	}
	
	
	@Test
	public void businessAnnotation() throws Exception {
		ArchRule rule = classes()
				.that().areAnnotatedWith(Service.class)
				.should().resideInAnyPackage(BUSINESS_PACKAGE + SUBPACKAGES);
		rule.check(classesAnalyzed);
	}
	
	@Test
	public void dataaccessAnnotation() throws Exception {
		ArchRule rule = classes()
				.that().areAnnotatedWith(Repository.class)
				.should().resideInAnyPackage(DATA_ACCESS_PACKAGE + SUBPACKAGES);
		rule.check(classesAnalyzed);
	}
}
