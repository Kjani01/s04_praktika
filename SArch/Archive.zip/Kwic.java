package edu.hm.cs.module.kwic.main;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Implementierung eines Systems zur Erstellung eines KWIC-Indexes mit global
 * zugreifbaren Datenstrukturen.
 * 
 * @author katz.bastian
 */
public class Kwic {

	private static final Logger log = LoggerFactory.getLogger(Kwic.class);

	private static List<String> lines = new ArrayList<>();
	private static List<String> rotations = new ArrayList<>();
	private static List<String> rotationsFormated = new ArrayList<>();

	public static void main(String[] args) {
		readInput("input.txt");
		addComma();
		cycle();
		format();
		sort();
		output();
	}

	/**
	 * Method zum Einlesen der Zeilen aus einer Datei.
	 * 
	 * @param fileName
	 *            Dateiname
	 */
	private static void readInput(String fileName) {
		Path inFile = Paths.get(fileName);
		try {
			lines.addAll(Files.readAllLines(inFile));
		} catch (IOException e) {
			log.error("Fehler beim Einlesen: " + e);
			System.exit(1);
		}
	}

	private static void addComma() {

		for (int i = 0; i < lines.size(); i++)
			lines.set(i, lines.get(i).trim() + ",");
	}

	/**
	 * Methode zur Erstellung aller zyklischer Rotationen aus den Zeilen.
	 */
	private static void cycle() {
		for (String line : lines) {
			String[] words = line.trim().split(" ");
			int count = words.length;
			for (int i = 0; i < count; i++) {
				StringBuffer sb = new StringBuffer();
				for (int j = 0; j < count; j++) {
					sb.append(words[(i + j) % count] + " ");
				}
				rotations.add(sb.substring(0, sb.length() - 1));
			}
		}
	}

	private static void format() {
		for (String entry : rotations) {
			if (!entry.startsWith("The")) {
				rotationsFormated.add(entry);
			}
		}
	}

	/**
	 * Ausgabe der Rotationen.
	 */
	private static void output() {
		for (String entry : rotationsFormated) {
			if (!entry.endsWith(","))
				System.out.println(entry);
			else
				System.out.println(entry.substring(0, entry.length() - 1));
		}
	}

	/**
	 * Methode zum Sortieren der Rotationen.
	 */
	private static void sort() {
		Collections.sort(rotationsFormated);
	}
}
