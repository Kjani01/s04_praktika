package edu.hm.cs.softarch.kwic.oop;

public interface Output {

	public void print(Sorter sorter);
	
}
