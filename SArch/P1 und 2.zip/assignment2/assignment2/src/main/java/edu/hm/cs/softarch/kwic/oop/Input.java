package edu.hm.cs.softarch.kwic.oop;

import java.util.List;

public interface Input {

	public List<String> read(Shifter shifter);
	
}
