package edu.hm.cs.softarch.kwic.oop;

import java.util.List;

public interface Entry {

	public String getWord();
	
	public List<String> getPreContext();
	
	public List<String> getPostContext();
	
	public boolean hasPostContext();
	
	public boolean hasPreContext();
}
