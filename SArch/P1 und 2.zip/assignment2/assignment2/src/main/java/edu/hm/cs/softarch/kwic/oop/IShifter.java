package edu.hm.cs.softarch.kwic.oop;

import java.util.List;

public interface IShifter{

	public void addPhrase(String phrase);
	
	public List<Entry> getEntries();
	
}
