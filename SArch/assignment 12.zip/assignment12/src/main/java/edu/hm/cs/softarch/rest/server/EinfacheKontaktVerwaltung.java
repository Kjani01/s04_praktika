package edu.hm.cs.softarch.rest.server;

import java.util.HashMap;
import java.util.Map;

import javax.annotation.PostConstruct;

import org.springframework.stereotype.Component;

import edu.hm.cs.softarch.rest.shared.Kontakt;
import edu.hm.cs.softarch.rest.shared.KontaktListe;

/**
 * Einfache, Map-basierte Implementierung einer {@link KontaktVerwaltung}.
 * @author katz.bastian
 */
@Component
public class EinfacheKontaktVerwaltung implements KontaktVerwaltung {

	private Map<Long, Kontakt> kontakte = new HashMap<>();
	private long nextId = 1;
	
	@Override
	public KontaktListe findeAlleKontakte() {
		KontaktListe result = new KontaktListe();
		result.addAll(kontakte.values());
		return result;
	}

	@Override
	public void aendereKontakt(Kontakt kontakt) {
		if (kontakt.getId() == null) {
			throw new IllegalArgumentException("Änderung nur mit ID möglich!");
		}
		if (!kontakte.containsKey(kontakt.getId())) {
			throw new IllegalArgumentException("Kontakt ist nicht enthalten mit ID: "+kontakt.getId());
		}
		kontakte.put(kontakt.getId(), kontakt);
	}
	
	@Override
	public Long erstelleKontakt(Kontakt kontakt) {
		kontakt.setId(nextId++);
		kontakte.put(kontakt.getId(), kontakt);
		return kontakt.getId();
	}

	@Override
	public Kontakt findeKontakt(Long id) {
		return kontakte.get(id);
	}

	@Override
	public void loescheKontakt(Long id) {
		kontakte.remove(id);
	}

	@PostConstruct
	public void initDummyData() {
		Kontakt k = new Kontakt();
		k.setName("xxx");
		k.setMail("lala2@mail.com");
		k.setTelefon("+49 292 23124123");
		erstelleKontakt(k);
	}
	
	
}
