package edu.hm.cs.softarch.rest.server;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;

/**
 * Spring Boot Webanwendung.
 * 
 * @author katz.bastian
 */
@SpringBootApplication
public class KontaktServer extends WebSecurityConfigurerAdapter {

	public static void main(String[] args) {
		SpringApplication.run(KontaktServer.class, args);
	}

	@Override
	protected void configure(HttpSecurity http) throws Exception {
		http.authorizeRequests().anyRequest().permitAll();
		http.headers().frameOptions().disable();
		http.csrf().disable();
	}
}
