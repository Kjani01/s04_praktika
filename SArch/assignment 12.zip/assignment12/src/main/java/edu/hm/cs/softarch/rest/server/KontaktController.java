package edu.hm.cs.softarch.rest.server;

import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import edu.hm.cs.softarch.rest.shared.Kontakt;
import edu.hm.cs.softarch.rest.shared.KontaktListe;

/**
 * REST-konformer Controller für den Zugriff auf Kontakte.
 * 
 * @see KontaktListe
 * @see Kontakt
 * 
 * @author katz.bastian
 */
@RestController
@RequestMapping("/kontakte")
public class KontaktController {

	private KontaktVerwaltung kontaktVerwaltung;

	@Autowired
	public KontaktController(KontaktVerwaltung kontaktVerwaltung) {
		this.kontaktVerwaltung = kontaktVerwaltung;
	}

//	@GetMapping
//	public KontaktListe findeKontakte() {
//		return kontaktVerwaltung.findeAlleKontakte();
//	}
	
	@GetMapping
	public KontaktListe findeKontakte(@RequestParam(name="filter", defaultValue="") String filter) {
		
		KontaktListe liste = kontaktVerwaltung.findeAlleKontakte();
		KontaktListe ergebnis = new KontaktListe();
		
		for (Kontakt k : liste) {
			if (k.getName().contains(filter)) {
				ergebnis.add(k);
			}
		}
		
		//liste.stream().filter(k -> k.getName().equals(filter)).collect(Collectors.toList());
		
		return ergebnis;
	}
	
	@PostMapping
	public Kontakt create(@RequestBody Kontakt k) {
		return kontaktVerwaltung.findeKontakt(kontaktVerwaltung.erstelleKontakt(k));
	}
	
	@DeleteMapping("/{id}")
	public void delete (@PathVariable("id") Long id) {
		kontaktVerwaltung.loescheKontakt(id);		
	}
	
	@PutMapping("/{id}")
	public Kontakt change (@RequestBody Kontakt k, @PathVariable("id") Long id) {
		
		String name = k.getName();
		String mail = k.getMail();
		String telefon = k.getTelefon();
		
		kontaktVerwaltung.findeKontakt(id).setName(name);
		kontaktVerwaltung.findeKontakt(id).setMail(mail);
		kontaktVerwaltung.findeKontakt(id).setTelefon(telefon);
		
		return kontaktVerwaltung.findeKontakt(id);
	}
	
	
}
