package edu.hm.cs.softarch.rest.client;

import javax.swing.table.AbstractTableModel;

import edu.hm.cs.softarch.rest.shared.Kontakt;
import edu.hm.cs.softarch.rest.shared.KontaktListe;

/**
 * Einfaches {@link AbstractTableModel} zum Mapping einer {@link KontaktListe}
 * auf eine Tabelle.
 * 
 * @author katz.bastian
 */
final class KontaktTableModel extends AbstractTableModel {

	private static final long serialVersionUID = 1L;

	private final KontaktListe kontakte;

	/**
	 * @param kontaktClient
	 */
	KontaktTableModel(KontaktListe kontakte) {
		this.kontakte = kontakte;
	}

	final String[] COLNAMES = new String[] { "ID", "Name", "Mail", "Telefon" };

	@Override
	public String getColumnName(int column) {
		return COLNAMES[column];
	}

	@Override
	public Object getValueAt(int arg0, int arg1) {
		Kontakt k = kontakte.get(arg0);
		switch (arg1) {
		case 0:
			return k.getId();
		case 1:
			return k.getName();
		case 2:
			return k.getMail();
		case 3:
			return k.getTelefon();
		default:
			return "--";
		}
	}

	@Override
	public int getRowCount() {
		return kontakte.size();
	}

	@Override
	public int getColumnCount() {
		return 4;
	}

	@Override
	public boolean isCellEditable(int rowIndex, int columnIndex) {
		return false;
	}
}