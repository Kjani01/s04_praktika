package edu.hm.cs.softarch.rest.server;

import edu.hm.cs.softarch.rest.shared.Kontakt;
import edu.hm.cs.softarch.rest.shared.KontaktListe;

/**
 * Interface für die eigentliche Server-Funktionalität zum Speichern von
 * Kontakten. Implementierungen könnten eine echte Persistenz verwenden, der
 * Einfachheit halber liefern wir nur eine ganz einfache nicht-persistente
 * Implementierung.
 * 
 * @author katz.bastian
 */
public interface KontaktVerwaltung {

	KontaktListe findeAlleKontakte();
	
	void aendereKontakt(Kontakt kontakt);
	
	Kontakt findeKontakt(Long id);
	
	void loescheKontakt(Long id);

	Long erstelleKontakt(Kontakt kontakt);
}
