package edu.hm.cs.softarch.rest.client;

import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;

import org.springframework.web.client.RestTemplate;

import edu.hm.cs.softarch.rest.shared.Kontakt;
import edu.hm.cs.softarch.rest.shared.KontaktListe;

/**
 * Kleiner Client für den Kontaktserver. Greift per REST-Schnittstelle auf den
 * Server zu.
 * 
 * @author katz.bastian
 */
public class KontaktClient extends JFrame {

	private static final long serialVersionUID = 1L;

	/**
	 * Start des Clients. Erwartet den Server laufend auf localhost:8000!
	 * 
	 * @param args
	 *            nicht verwendet
	 */
	public static void main(String[] args) {
		new KontaktClient("http://localhost:8000");
	}

	private final RestTemplate restTemplate = new RestTemplate();
	private final String baseUrl;

	// Aktuelle Daten vom letzten GET der Liste
	private KontaktListe kontakte = new KontaktListe();

	// benötigte UI Widgets
	private JTable table;
	private JTextField filterField;
	private JButton filter;
	private JTextField idField;
	private JTextField nameField;
	private JTextField phoneField;
	private JTextField mailField;
	private JButton clear;
	private JButton save;
	private JButton delete;

	public KontaktClient(String baseUrl) {
		this.baseUrl = baseUrl;
		this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

		// Erzeugung der UI ist ausgelagert & muss nicht verändert werden.
		createPanel();

		// Bei Drücken des Clear-Buttons wird das Formular zurückgesetzt
		clear.addActionListener(e -> {
			nameField.setText("");
			phoneField.setText("");
			idField.setText("");
			mailField.setText("");
			table.clearSelection();
		});

		// Bei Auswahl eines geladenen Kontakts wird Kontakt in Formular
		// eingetragen (zum Ändern oder Löschen)
		table.getSelectionModel().addListSelectionListener(e -> {
			int index = table.getSelectedRow();
			if (index >= 0) {
				Kontakt k = kontakte.get(index);
				nameField.setText(k.getName());
				phoneField.setText(k.getTelefon());
				idField.setText(String.valueOf(k.getId()));
				mailField.setText(k.getMail());
			}
		});

		// Beim Speichern soll entweder ein neuer Kontakt angelegt oder ein
		// bestehender gespeichert werden. Das lässt sich daran erkennen, ob das
		// ID-Feld leer ist (neuer Eintrag) oder gefüllt (Ändern.
		save.addActionListener(e -> {
			if (!idField.getText().equals("")) {
				System.err.println("Wir sind im IF");
				System.err.println("idField: " + idField.getText());
				Kontakt k = new Kontakt();
				k.setName(nameField.getText());
				k.setMail(mailField.getText());
				k.setTelefon(phoneField.getText());
				
				restTemplate.put(baseUrl + "/kontakte/" + idField.getText(), k, idField.getText());
			}
			else {
				System.err.println("Wir sind im Else");
				Kontakt k = new Kontakt();
				k.setName(nameField.getText());
				k.setMail(mailField.getText());
				k.setTelefon(phoneField.getText());
				
				restTemplate.postForObject(baseUrl + "/kontakte", k, Kontakt.class);

				
			}
			
			refresh();
		});

		// Beim Löschen soll ggf. der angezeigte Kontakt gelöscht werden.
		delete.addActionListener(e -> {
			
			if (idField.getText() != "") {
				restTemplate.delete(baseUrl + "/kontakte/" + idField.getText());
			}
			
			// TODO: Löschen von Elementen fehlt noch
			refresh();
		});

		// Beim Filtern soll die Liste neu geladen werden (Berücksichtigung des
		// Filtertextes).
		filter.addActionListener(e -> {
			refresh();
		});

		refresh();
		this.pack();
		this.setVisible(true);
	}

	// Diese Methode enthält den Aufruf zum Laden der Liste. Hier sollte der
	// Filtertext berücksichtigt werden.
	private void refresh() {
		// TODO: In diesem Aufruf fehlt noch ein Filterparameter
		
		
		kontakte = restTemplate.getForObject(baseUrl + "/kontakte?filter=" + filterField.getText(), KontaktListe.class);		
		table.setModel(new KontaktTableModel(kontakte));
		table.repaint();
		
	}

	/*
	 * Unterhalb von diesem Punkt kommt nur noch Erzeugung und Layout, keine
	 * Änderungen notwendig!
	 */

	private void createPanel() {
		JPanel panel = new JPanel(new GridBagLayout());
		this.add(panel);

		GridBagConstraints c = new GridBagConstraints();
		table = new JTable();
		JScrollPane scrollPane = new JScrollPane(table);
		table.setFillsViewportHeight(true);
		c.gridheight = 10;
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 0;
		c.gridy = 0;
		panel.add(scrollPane, c);

		filter = new JButton("filter/refresh");
		c.gridwidth = 1;
		c.gridheight = 1;
		c.gridx = 1;
		c.gridy = 0;
		c.insets = new Insets(5, 5, 40, 5);
		panel.add(filter, c);

		filterField = new JTextField(15);
		c.gridx = 2;
		panel.add(filterField, c);

		idField = createTextField("ID", 1, panel);
		idField.setEnabled(false);
		nameField = createTextField("Name", 2, panel);
		mailField = createTextField("Mail", 3, panel);
		phoneField = createTextField("Telefon", 4, panel);

		clear = createBigButton("zurücksetzen", 5, panel);
		save = createBigButton("sichern", 6, panel);
		delete = createBigButton("löschen", 7, panel);
	}

	private JTextField createTextField(String label, int row, JPanel panel) {
		GridBagConstraints c = new GridBagConstraints();
		c.fill = GridBagConstraints.HORIZONTAL;
		c.insets = new Insets(5, 5, 5, 5);
		JLabel jLabel = new JLabel(label);
		c.gridx = 1;
		c.gridy = row;
		panel.add(jLabel, c);

		JTextField result = new JTextField(15);
		c.gridx = 2;
		panel.add(result, c);
		return result;
	}

	private JButton createBigButton(String label, int row, JPanel panel) {
		JButton button = new JButton(label);
		GridBagConstraints c = new GridBagConstraints();
		c.fill = GridBagConstraints.HORIZONTAL;
		c.insets = new Insets(5, 5, 5, 5);
		c.gridx = 1;
		c.gridy = row;
		c.gridwidth = 2;
		panel.add(button, c);
		return button;
	}

}
