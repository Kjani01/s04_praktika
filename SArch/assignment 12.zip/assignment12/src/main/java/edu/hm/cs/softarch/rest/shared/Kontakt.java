package edu.hm.cs.softarch.rest.shared;

/**
 * Klasse für Kontaktdaten. Wird zur Komunikation mit dem Client serialisiert.
 * 
 * @author katz.bastian
 */
public class Kontakt {

	private Long id;
	private String name;
	private String mail;
	private String telefon;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getMail() {
		return mail;
	}

	public void setMail(String mail) {
		this.mail = mail;
	}

	public String getTelefon() {
		return telefon;
	}

	public void setTelefon(String telefon) {
		this.telefon = telefon;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}
}
