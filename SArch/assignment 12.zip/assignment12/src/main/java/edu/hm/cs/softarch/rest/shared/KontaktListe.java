package edu.hm.cs.softarch.rest.shared;

import java.util.ArrayList;

/**
 * Liste von Kontakten. Wird als eigener nicht-generischer Typ benötigt, um
 * Konvertierungen zu erleichtern. Geht auch anders, ist aber schwer
 * durchschaubar.
 * 
 * @author katz.bastian
 */
public class KontaktListe extends ArrayList<Kontakt> {

	private static final long serialVersionUID = 1L;

}
