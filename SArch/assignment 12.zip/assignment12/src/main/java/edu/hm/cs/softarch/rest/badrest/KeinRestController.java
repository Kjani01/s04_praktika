package edu.hm.cs.softarch.rest.badrest;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/demo")
public class KeinRestController {

	@PostMapping("/calc")
	public Output multiply(@RequestBody Input input) {
		Output result = new Output();
		int a = input.getNumber1();
		int b = input.getNumber2();
		result.setNumber1(a);
		result.setNumber2(b);
		result.setProduct(a*b);
		result.setDifference(a-b);
		return result;		
	}

	@GetMapping("/multiply")
	public Integer multiply(@RequestParam("a") int a, @RequestParam("b") int b) {

		return a * b;
	}
}
