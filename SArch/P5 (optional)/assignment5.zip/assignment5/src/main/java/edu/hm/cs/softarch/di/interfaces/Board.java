package edu.hm.cs.softarch.di.interfaces;

public interface Board extends BoardReader {
	void set(int row, int col, Player player) throws MoveException;
}
