package edu.hm.cs.softarch.di;

import org.apache.commons.lang3.tuple.Pair;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import edu.hm.cs.softarch.di.interfaces.Ai;
import edu.hm.cs.softarch.di.interfaces.Board;
import edu.hm.cs.softarch.di.interfaces.Display;
import edu.hm.cs.softarch.di.interfaces.HumanInput;
import edu.hm.cs.softarch.di.interfaces.MoveException;
import edu.hm.cs.softarch.di.interfaces.Player;
import edu.hm.cs.softarch.di.interfaces.Rules;
import implementations.ConsoleDisplay;
import implementations.ConsoleInput;
import implementations.NonPersistentBoard;
import implementations.RandomAi;
import implementations.StandardRules;

@Component
public class TicTacToeApplication implements CommandLineRunner {

	private Board board = new NonPersistentBoard();
	private Rules rules = new StandardRules(board);
	private Display display = new ConsoleDisplay(board, rules);
	private Ai ai = new RandomAi(board);
	private HumanInput input = new ConsoleInput();
	
	@Autowired
	public TicTacToeApplication(Board board, Rules rules, Display display, Ai ai, HumanInput input) {
		this.board = board;
		this.rules = rules;
		this.display = display;
		this.ai = ai;
		this.input = input;
	}
	
	@Override
	public void run(String... args) throws Exception {
		display.update();

		for (Player player = Player.HUMAN; !rules.gameIsOver(); player = Player.next(player)) {

			// Zug eines Mitspielers mit Wiederholung
			if (player == Player.HUMAN) {
				System.out.println("\nSpieler ist am Zug!");
				boolean moveAccepted = true;
				do {
					moveAccepted = true;
					Pair<Integer, Integer> move = input.getMove();
					try {
						board.set(move.getLeft(), move.getRight(), player);
					} catch (MoveException e) {
						moveAccepted = false;
						System.out.println("Unerlaubter Zug!");
					}
				} while (!moveAccepted);
			}

			// Zug des Computers ohne Wiederholung
			if (player == Player.AI) {
				Pair<Integer, Integer> move = ai.getMove();
				System.out.println("\n Computer setzt: " + move.getLeft() + "/" + move.getRight());
				try {
					board.set(move.getLeft(), move.getRight(), player);
				} catch (MoveException e) {
					throw new RuntimeException("Dumb AI.");
				}
			}
			display.update();
		}

		// Ausgabe des Gewinners!
		display.declareWinner();	
		
	}

}
