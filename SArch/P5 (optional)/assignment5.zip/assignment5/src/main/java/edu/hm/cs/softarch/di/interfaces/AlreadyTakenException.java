package edu.hm.cs.softarch.di.interfaces;

public class AlreadyTakenException extends MoveException {

	private static final long serialVersionUID = 1L;

}
