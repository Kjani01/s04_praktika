package edu.hm.cs.softarch.di.interfaces;

import java.util.Optional;

public interface BoardReader {
	Optional<Player> get(int row, int col);
	boolean isValid(int row, int col);
}
