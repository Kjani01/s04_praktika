package edu.hm.cs.softarch.di.interfaces;

public interface Rules {

	boolean gameIsOver();

	boolean isWinner(Player player);

}
