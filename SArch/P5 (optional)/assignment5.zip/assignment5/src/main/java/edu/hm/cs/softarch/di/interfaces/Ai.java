package edu.hm.cs.softarch.di.interfaces;

import org.apache.commons.lang3.tuple.Pair;

public interface Ai {
	Pair<Integer, Integer> getMove();
}
