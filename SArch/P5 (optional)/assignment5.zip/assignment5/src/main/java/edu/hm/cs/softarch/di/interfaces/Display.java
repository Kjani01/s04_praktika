package edu.hm.cs.softarch.di.interfaces;

public interface Display {
	void update();

	void declareWinner();
}
