package edu.hm.cs.softarch.di.interfaces;

public class MoveException extends Exception {

	private static final long serialVersionUID = 1L;

}
