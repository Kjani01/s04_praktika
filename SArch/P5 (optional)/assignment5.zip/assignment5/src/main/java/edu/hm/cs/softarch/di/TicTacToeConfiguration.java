package edu.hm.cs.softarch.di;

import org.springframework.boot.WebApplicationType;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.EnableAspectJAutoProxy;

@Configuration
@ComponentScan(basePackages = {"edu.hm.cs.softarch.di", "implementations"})
@EnableAspectJAutoProxy
public class TicTacToeConfiguration {

	// Starten Sie diese main-Methode, um den Kontext zu erstellen und nach
	// einem CommandLineRunner zu suchen.
	public static void main(String[] args) {
		new SpringApplicationBuilder(TicTacToeConfiguration.class).web(WebApplicationType.NONE).run(args);
	}

}
