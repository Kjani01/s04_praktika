package edu.hm.cs.softarch.di.interfaces;

public enum Player {
	HUMAN, AI;
	
	public static Player next(Player player) {
		if (player==AI) return HUMAN;
		return AI;
	}
}
