package implementations;

import java.util.Optional;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Component;

import edu.hm.cs.softarch.di.interfaces.AlreadyTakenException;
import edu.hm.cs.softarch.di.interfaces.Board;
import edu.hm.cs.softarch.di.interfaces.MoveException;
import edu.hm.cs.softarch.di.interfaces.Player;

@Component
public class NonPersistentBoard implements Board {

	Player[][] board = new Player[3][3];
	
	@Override
	public Optional<Player> get(int row, int col) {
		return Optional.ofNullable(board[row][col]);
	}

	@Override
	public void set(int row, int col, Player player) throws MoveException {
		if (row<0 || row>2 || col<0 || col>2) {
			throw new MoveException();
		}
		if (!isValid(row, col)) {
			throw new AlreadyTakenException();
		}
		board[row][col] = player;
		
	}

	@Override
	public boolean isValid(int row, int col) {		
		return !get(row, col).isPresent();
	}

}
