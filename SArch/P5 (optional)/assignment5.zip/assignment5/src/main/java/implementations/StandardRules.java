package implementations;

import java.util.Optional;

import org.springframework.stereotype.Component;

import edu.hm.cs.softarch.di.interfaces.BoardReader;
import edu.hm.cs.softarch.di.interfaces.Player;
import edu.hm.cs.softarch.di.interfaces.Rules;

@Component
public class StandardRules implements Rules {

	BoardReader board;
			
	public StandardRules(BoardReader board) {
		this.board = board;
	}

	public Optional<Player> winner() {
		for (Player p: Player.values()) {
			if (isWinner(p)) return Optional.of(p);
		}
		return Optional.ofNullable(null);
	}
	
	@Override
	public boolean isWinner(Player player) {
		for (int i = 0; i<3; i++) {
			boolean winsRow = true;
			boolean winsCol = true;
			for (int j = 0; j<3; j++) {
				Optional<Player> x = board.get(i, j);
				if (!x.isPresent() || x.get()!=player) {
					winsRow = false;
				}
				x = board.get(j, i);
				if (!x.isPresent() || x.get()!=player) {
					winsCol = false;
				}	
			}
			if (winsRow || winsCol) return true;
		}
		//TODO: check diagonals
		
		return false;
	}
	
	@Override
	public boolean gameIsOver() {
		if (winner().isPresent()) return true;
		for (int row = 0; row<3; row++) {
			for (int col = 0; col<3; col++) {
				if (!board.get(row, col).isPresent()) return false;
			}
		}
		return true;
	}
	
}
