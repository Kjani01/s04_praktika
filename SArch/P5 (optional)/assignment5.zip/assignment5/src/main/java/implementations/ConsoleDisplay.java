package implementations;

import org.springframework.stereotype.Component;

import edu.hm.cs.softarch.di.interfaces.BoardReader;
import edu.hm.cs.softarch.di.interfaces.Display;
import edu.hm.cs.softarch.di.interfaces.Player;
import edu.hm.cs.softarch.di.interfaces.Rules;

@Component
public class ConsoleDisplay implements Display {

	private BoardReader board;
	private Rules rules;
	
	public ConsoleDisplay(BoardReader board, Rules rules) {
		this.board = board;
		this.rules = rules;
	}

	@Override
	public void update() {
		System.out.println("\n\n   0  1  2");
		System.out.println("  =========");
		for (int row = 0; row<3; row++) {
			System.out.print(row+"|");
			for (int col = 0; col<3; col++) {
				String marker = "   ";
				if (board.get(row, col).isPresent()) {
					marker = " X ";
					if (board.get(row, col).get()==Player.AI) {
						marker = " O ";
					}
					
				}	
				System.out.print(marker);				
			}
			System.out.println();
		}
		System.out.println("  =========");

	}

	@Override
	public void declareWinner() {
		if (rules.isWinner(Player.AI)) {
			System.out.println("Verloren!");
		} else if (rules.isWinner(Player.HUMAN)) {
			System.out.println("Gewonnen!");
		} else {
			System.out.println("Unentschieden!");
		}
	}

}
