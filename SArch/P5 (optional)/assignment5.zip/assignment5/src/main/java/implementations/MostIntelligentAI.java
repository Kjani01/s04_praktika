package implementations;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.Random;

import org.apache.commons.lang3.tuple.ImmutablePair;
import org.apache.commons.lang3.tuple.Pair;
import org.springframework.stereotype.Component;

import edu.hm.cs.softarch.di.interfaces.Ai;
import edu.hm.cs.softarch.di.interfaces.BoardReader;
import edu.hm.cs.softarch.di.interfaces.Player;

@Component
public class MostIntelligentAI implements Ai {

	Random r = new Random();

	private BoardReader board;

	public MostIntelligentAI(BoardReader board) {
		this.board = board;
	}

	@Override
	public Pair<Integer, Integer> getMove() {

		int[][] arr = new int[3][3];
		Arrays.deepToString(arr);

		for (int i = 0; i < 3; i++) {
			for (int j = 0; j < 3; j++) {
				if (board.get(i, j).isPresent()) {
					if (board.get(i, j).get() == Player.HUMAN)
						arr[i][j] = 1;
					else if (board.get(i, j).get() == Player.AI)
						arr[i][j] = 10;
					else
						arr[i][j] = 0;
				}
			}
		}

		int row = 0;
		int col = 0;
		do {
			row = r.nextInt(3);
			col = r.nextInt(3);
		} while (!board.isValid(row, col));

		for (int i = 0; i < 3; i++) {
			int sum = 0;
			for (int j = 0; j < 3; j++) {
				sum += arr[i][j];
			}
			System.out.println("Zeilensumme: " + sum);
		}

		return new ImmutablePair<Integer, Integer>(row, col);
	}

}
