package implementations;

import java.util.Scanner;

import org.apache.commons.lang3.tuple.ImmutablePair;
import org.apache.commons.lang3.tuple.Pair;
import org.springframework.stereotype.Component;

import edu.hm.cs.softarch.di.interfaces.HumanInput;

@Component
public class ConsoleInput implements HumanInput {

	@Override
	public Pair<Integer, Integer> getMove() {

		int row = input("Zeile ");
		int col = input("Spalte");
		return new ImmutablePair<Integer, Integer>(row, col);
	}

	private int input(String name) {
		Scanner scanner = new Scanner(System.in);
		System.out.print(name + " > ");
		while (scanner.hasNext() && !scanner.hasNextInt()) {
			System.out.print(name + " > ");
			scanner.next();
		}
		int result = scanner.nextInt();
		return result;

	}

}
