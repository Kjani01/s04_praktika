package implementations;

import java.util.Random;

import org.apache.commons.lang3.tuple.ImmutablePair;
import org.apache.commons.lang3.tuple.Pair;
import org.springframework.stereotype.Component;

import edu.hm.cs.softarch.di.interfaces.Ai;
import edu.hm.cs.softarch.di.interfaces.BoardReader;

//@Component
public class RandomAi implements Ai {

	Random r = new Random();
	
	private BoardReader board;

	public RandomAi(BoardReader board) {
		this.board = board;			
	}
	
	@Override
	public Pair<Integer, Integer> getMove() {
		int row = 0;
		int col = 0;
		do {
			row = r.nextInt(3);
			col = r.nextInt(3);
		} while (!board.isValid(row, col));
		
		return new ImmutablePair<Integer,Integer>(row, col);
	}

}
