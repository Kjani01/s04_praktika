package edu.hm.cs.softarch.kwic.dip;

public abstract class AbstractFactory {
	
	public abstract void create(String phraseFileName);
	
	public abstract void print();

}
