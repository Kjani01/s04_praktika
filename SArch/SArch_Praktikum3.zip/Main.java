package edu.hm.cs.softarch.kwic.dip;

/**
 * Main-Klasse zur Demonstration der Kwic-Indexerstellung.
 * 
 * @author katz.bastian
 *
 */
public class Main {

	public static void main(String[] args) {
		new Kwic("input.txt");//.print();
	}
}
