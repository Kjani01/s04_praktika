package edu.hm.cs.softarch.dataflow.batch.pojos;

public enum Ergebnis {
	BESTANDEN, NICHT_BESTANDEN
}
