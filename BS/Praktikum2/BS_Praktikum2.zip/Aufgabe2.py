import time

def processes(parameter):
	while True:
		print (parameter)
		time.sleep(10)

processes("hello")
